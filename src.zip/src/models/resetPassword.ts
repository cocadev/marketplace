export class ResetPassword {
    token: string;
    email: string;
    password: string;
    password_confirmation: string;
}