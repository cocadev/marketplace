export class UserUpload {
    passport: any;
    utility_bill: any;
    utility_billName: string;
    passportName: string;
}