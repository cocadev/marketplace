export class RegisterModel {
    username: string;
    email: string;
    title: string;
    first_name: string;
    last_name: string;
    phone: string;
    password: string;
    password_confirmation: string;
}


